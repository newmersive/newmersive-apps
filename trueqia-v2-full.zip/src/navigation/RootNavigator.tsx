import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useAuthStore } from "../store/auth.store";

import DemoLandingScreen from "../screens/Demo/DemoLandingScreen";
import DemoOffersScreen from "../screens/Demo/DemoOffersScreen";
import DemoOfferDetailScreen from "../screens/Demo/DemoOfferDetailScreen";

import LoginScreen from "../screens/Auth/LoginScreen";
import RegisterScreen from "../screens/Auth/RegisterScreen";

import MainTabs from "./MainTabs";
import AdminDashboardScreen from "../screens/Admin/AdminDashboardScreen";
import ContractPreviewScreen from "../screens/Contracts/ContractPreviewScreen";

const Stack = createNativeStackNavigator();

export default function RootNavigator() {
  const user = useAuthStore((s) => s.user);
  const isLogged = Boolean(user);
  const isAdmin = user?.role === "admin";

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="DemoLanding" component={DemoLandingScreen} />
      <Stack.Screen name="DemoOffers" component={DemoOffersScreen} />
      <Stack.Screen name="DemoOfferDetail" component={DemoOfferDetailScreen} />

      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />

      {isLogged && (
        <>
          <Stack.Screen name="MainTabs" component={MainTabs} />
          <Stack.Screen name="ContractPreview" component={ContractPreviewScreen} />
          {isAdmin && (
            <Stack.Screen
              name="AdminDashboard"
              component={AdminDashboardScreen}
            />
          )}
        </>
      )}
    </Stack.Navigator>
  );
}
