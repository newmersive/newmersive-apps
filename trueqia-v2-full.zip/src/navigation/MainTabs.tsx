import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

import HomeScreen from "../screens/Home/HomeScreen";
import OffersListScreen from "../screens/Offers/OffersListScreen";
import RequestsListScreen from "../screens/Requests/RequestsListScreen";
import ChatListScreen from "../screens/Chats/ChatListScreen";
import ProfileMainScreen from "../screens/Profile/ProfileMainScreen";

const Tab = createBottomTabNavigator();

export default function MainTabs() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: true }}>
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Offers" component={OffersListScreen} />
      <Tab.Screen name="Requests" component={RequestsListScreen} />
      <Tab.Screen name="Chats" component={ChatListScreen} />
      <Tab.Screen name="Profile" component={ProfileMainScreen} />
    </Tab.Navigator>
  );
}
